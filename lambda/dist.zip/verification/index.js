"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const crypto_1 = require("crypto");
const util_1 = require("util");
class VerificationProvider {
    constructor(dynamodb = new aws_sdk_1.DynamoDB.DocumentClient({
        apiVersion: "2012-08-10"
    })) {
        this.dynamodb = dynamodb;
    }
    async issue(subject) {
        const code = {
            id: (await util_1.promisify(crypto_1.randomBytes)(16)).toString("hex"),
            subject,
            expires: Math.floor(Date.now() / 1000) + 7 * 24 * 3600
        };
        await this.dynamodb.put({
            TableName: process.env.DYNAMODB_TABLE,
            Item: code
        }).promise();
        return code;
    }
    async claim(code) {
        const { Attributes } = await this.dynamodb.delete({
            TableName: process.env.DYNAMODB_TABLE,
            Key: { id: code },
            ReturnValues: "ALL_OLD"
        }).promise();
        if (!Attributes)
            throw new Error(`Invalid verification code: ${code}`);
        return Attributes;
    }
}
exports.VerificationProvider = VerificationProvider;
