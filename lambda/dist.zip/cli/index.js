"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
const yargs = require("yargs");
const authentication_1 = require("../clients/authentication");
const management_1 = require("../clients/management");
function print(data) {
    console.log(JSON.stringify(data, undefined, 2));
}
exports.print = print;
yargs
    .locale("en")
    .usage("$0 [command] <options>", "Identity provider client")
    .help("help")
    .alias("h", "help")
    .command("register", "Register user with email address and password", y => y
    .usage("$0 register [options]")
    .example("$0 register --email <email> --password <password>", "")
    .option("email", {
    describe: "Email address",
    type: "string",
    required: true
})
    .option("password", {
    describe: "Password",
    type: "string",
    required: true
}), async (args) => {
    const client = new authentication_1.AuthenticationClient();
    print(await client.register(args.email, args.password));
})
    .command("verify", "Verify user", y => y
    .usage("$0 verify [options]")
    .example("$0 verify --username <username>", "")
    .option("username", {
    describe: "Username or email",
    type: "string",
    required: true
}), async (args) => {
    const client = new management_1.ManagementClient();
    await client.verifyUser(args.username);
})
    .command("authenticate", "Authenticate using credentials or refresh token", y => y
    .usage("$0 authenticate [options]")
    .example("$0 authenticate --username <username> --password <password>", "")
    .example("$0 authenticate --token <refresh-token>", "")
    .option("username", {
    describe: "Username or email",
    type: "string",
    implies: ["password"],
    conflicts: ["token"]
})
    .option("password", {
    describe: "Password",
    type: "string",
    implies: ["username"],
    conflicts: ["token"]
})
    .option("token", {
    describe: "Refresh token",
    type: "string",
    conflicts: ["username", "password"]
}), async (args) => {
    const client = new authentication_1.AuthenticationClient();
    print(await client.authenticate(args.username || args.token, args.password));
})
    .argv;
