"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function success(data) {
    return {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin": process.env.ACCESS_CONTROL_ORIGIN
        },
        body: data ? JSON.stringify(data) : ""
    };
}
exports.success = success;
function failure(err) {
    return {
        statusCode: err.statusCode,
        headers: {
            "Access-Control-Allow-Origin": process.env.ACCESS_CONTROL_ORIGIN
        },
        body: JSON.stringify({
            code: err.statusCode,
            message: err.message
        })
    };
}
exports.failure = failure;
