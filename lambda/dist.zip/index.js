"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
async function handler(event) {
    console.log(event);
    return {
        statusCode: 202,
        headers: {
            "Access-Control-Allow-Origin": process.env.ACCESS_CONTROL_ORIGIN
        },
        body: ""
    };
}
exports.handler = handler;
exports.authenticate = handler;
exports.register = handler;
exports.register_verify = handler;
exports.reset = handler;
exports.reset_verify = handler;
