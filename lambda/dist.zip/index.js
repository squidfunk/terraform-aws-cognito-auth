"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const authentication_1 = require("./clients/authentication");
const management_1 = require("./clients/management");
const verification_1 = require("./verification");
async function register(event) {
    const data = JSON.parse(event.body);
    const client = authentication_1.AuthenticationClient.factory();
    const code = await client.register(data.email, data.password);
    return {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin": process.env.ACCESS_CONTROL_ORIGIN
        },
        body: JSON.stringify(code)
    };
}
exports.register = register;
async function registerVerify(event) {
    const verification = new verification_1.VerificationProvider();
    const code = await verification.claim(event.pathParameters.token);
    const client = management_1.ManagementClient.factory();
    await client.verifyUser(code.subject);
    return {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin": process.env.ACCESS_CONTROL_ORIGIN
        },
        body: JSON.stringify(code)
    };
}
exports.registerVerify = registerVerify;
async function reset(event) {
    const data = JSON.parse(event.body);
    const client = authentication_1.AuthenticationClient.factory();
    const code = await client.forgotPassword(data.username);
    return {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin": process.env.ACCESS_CONTROL_ORIGIN
        },
        body: JSON.stringify(code)
    };
}
exports.reset = reset;
async function resetVerify(event) {
    const data = JSON.parse(event.body);
    const verification = new verification_1.VerificationProvider();
    const code = await verification.claim(event.pathParameters.token);
    const client = management_1.ManagementClient.factory();
    await client.changePassword(code.subject, data.password);
    return {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin": process.env.ACCESS_CONTROL_ORIGIN
        },
        body: JSON.stringify(code)
    };
}
exports.resetVerify = resetVerify;
async function authenticate(event) {
    const data = JSON.parse(event.body);
    const client = authentication_1.AuthenticationClient.factory();
    const session = await client.authenticate(data.username || data.token, data.password);
    return {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin": process.env.ACCESS_CONTROL_ORIGIN
        },
        body: JSON.stringify(session)
    };
}
exports.authenticate = authenticate;
