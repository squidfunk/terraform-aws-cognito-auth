"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const authentication_1 = require("../../clients/authentication");
const result = require("../../util/result");
async function post(event) {
    const { email, password } = JSON.parse(event.body);
    const auth = authentication_1.AuthenticationClient.factory();
    try {
        await auth.register(email, password);
    }
    catch (err) {
        return result.failure(err);
    }
    return result.success();
}
exports.post = post;
