"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __1 = require("..");
const authentication_1 = require("../../clients/authentication");
exports.post = __1.handler(async ({ username, password, token }) => {
    const auth = authentication_1.AuthenticationClient.factory();
    return auth.authenticate(username || token, password);
});
