"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const authentication_1 = require("../../clients/authentication");
const result = require("../../util/result");
async function post(event) {
    const { username } = JSON.parse(event.body);
    const auth = authentication_1.AuthenticationClient.factory();
    try {
        return result.success(await auth.forgotPassword(username));
    }
    catch (err) {
        return result.failure(err);
    }
}
exports.post = post;
