"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __1 = require("..");
const authentication_1 = require("../../clients/authentication");
exports.post = __1.handler("reset/verify", async ({ username }) => {
    const auth = authentication_1.AuthenticationClient.factory();
    await auth.forgotPassword(username);
});
