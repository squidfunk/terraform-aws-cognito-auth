"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const authentication_1 = require("../../clients/authentication");
const management_1 = require("../../clients/management");
const result = require("../../util/result");
async function post(event) {
    const { password } = JSON.parse(event.body);
    const auth = authentication_1.AuthenticationClient.factory();
    const mgmt = management_1.ManagementClient.factory();
    try {
        const { subject } = await auth.verify(event.pathParameters.code);
        await mgmt.changePassword(subject, password);
    }
    catch (err) {
        return result.failure(err);
    }
    return result.success();
}
exports.post = post;
