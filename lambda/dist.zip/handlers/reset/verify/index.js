"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __1 = require("../..");
const authentication_1 = require("../../../clients/authentication");
const management_1 = require("../../../clients/management");
exports.post = __1.handler(async ({ code, password }) => {
    const auth = authentication_1.AuthenticationClient.factory();
    const mgmt = management_1.ManagementClient.factory();
    const { subject } = await auth.verify("reset", code);
    await mgmt.changePassword(subject, password);
});
