"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const authentication_1 = require("../clients/authentication");
const result = require("../util/result");
async function post(event) {
    const { username, password, token } = JSON.parse(event.body);
    const auth = authentication_1.AuthenticationClient.factory();
    try {
        return result.success(await auth.authenticate(username || token, password));
    }
    catch (err) {
        return result.failure(err);
    }
}
exports.post = post;
