"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsonschema_1 = require("jsonschema");
function handler(schema, cb) {
    return async (event) => {
        const headers = {
            "Access-Control-Allow-Origin": process.env.ACCESS_CONTROL_ALLOW_ORIGIN
        };
        try {
            const data = JSON.parse(event.body || "{}");
            const result = jsonschema_1.validate(data, require(`./${schema}/index.json`));
            if (result.errors.length)
                throw new TypeError("Invalid request body");
            const body = await cb(Object.assign({}, event.pathParameters, data));
            return {
                statusCode: 200,
                headers,
                body: body ? JSON.stringify(body) : ""
            };
        }
        catch (err) {
            return {
                statusCode: err.statusCode || 400,
                headers,
                body: JSON.stringify({
                    message: err.message.replace(/\.$/, "")
                })
            };
        }
    };
}
exports.handler = handler;
