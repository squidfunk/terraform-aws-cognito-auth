"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const __1 = require("..");
class SessionClient extends __1.Client {
    constructor(session, cognito = new aws_sdk_1.CognitoIdentityServiceProvider({
        apiVersion: "2016-04-18"
    })) {
        super(cognito);
        this.session = session;
    }
    async changePassword(previous, proposed) {
        await this.cognito.changePassword({
            AccessToken: this.session.accessToken,
            PreviousPassword: previous,
            ProposedPassword: proposed
        }).promise();
    }
}
exports.SessionClient = SessionClient;
