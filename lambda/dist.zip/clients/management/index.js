"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const __1 = require("..");
class ManagementClient extends __1.Client {
    constructor(cognito = new aws_sdk_1.CognitoIdentityServiceProvider({
        apiVersion: "2016-04-18"
    })) {
        super(cognito);
    }
    async verifyUser(username) {
        await Promise.all([
            this.cognito.adminConfirmSignUp({
                UserPoolId: process.env.COGNITO_USER_POOL,
                Username: username
            }).promise(),
            this.cognito.adminUpdateUserAttributes({
                UserPoolId: process.env.COGNITO_USER_POOL,
                Username: username,
                UserAttributes: [
                    {
                        Name: "email_verified",
                        Value: "true"
                    }
                ]
            }).promise()
        ]);
    }
    async changePassword(username, password) {
        const { Username, UserAttributes } = await this.cognito.adminGetUser({
            UserPoolId: process.env.COGNITO_USER_POOL,
            Username: username
        }).promise();
        await this.cognito.adminDeleteUser({
            UserPoolId: process.env.COGNITO_USER_POOL,
            Username
        }).promise();
        await this.cognito.signUp({
            ClientId: process.env.COGNITO_USER_POOL_CLIENT,
            Username,
            Password: password,
            UserAttributes: UserAttributes.filter(attr => {
                return ["sub", "email_verified"].indexOf(attr.Name) === -1;
            })
        }).promise();
        await this.verifyUser(Username);
    }
}
exports.ManagementClient = ManagementClient;
