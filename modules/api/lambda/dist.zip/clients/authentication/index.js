"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const uuid = require("uuid/v4");
const clients_1 = require("clients");
const verification_1 = require("verification");
function expires(seconds) {
    return new Date(Date.now() + seconds * 1000);
}
exports.expires = expires;
function translate(err) {
    switch (err.code) {
        case "InvalidParameterException":
            err.code = "TypeError";
            err.message = "Invalid request";
            return err;
        case "UserNotFoundException":
            err.code = "NotAuthorizedException";
            err.message = "Incorrect username or password";
            return err;
        default:
            return err;
    }
}
exports.translate = translate;
class AuthenticationClient extends clients_1.Client {
    constructor(verification = new verification_1.Verification(), cognito = new aws_sdk_1.CognitoIdentityServiceProvider({
        apiVersion: "2016-04-18"
    })) {
        super(cognito);
        this.verification = verification;
    }
    async register(email, password) {
        const username = uuid();
        await this.cognito.signUp({
            ClientId: process.env.COGNITO_USER_POOL_CLIENT,
            Username: username,
            Password: password,
            UserAttributes: [
                {
                    Name: "email",
                    Value: email
                }
            ]
        }).promise();
        return this.verification.issue("register", username);
    }
    authenticate(usernameOrToken, password) {
        return password
            ? this.authenticateWithCredentials(usernameOrToken, password)
            : this.authenticateWithToken(usernameOrToken);
    }
    async forgotPassword(username) {
        const { Username: id } = await this.cognito.adminGetUser({
            UserPoolId: process.env.COGNITO_USER_POOL,
            Username: username
        }).promise();
        return this.verification.issue("reset", id);
    }
    async authenticateWithCredentials(username, password) {
        try {
            const { AuthenticationResult, ChallengeName } = await this.cognito.initiateAuth({
                ClientId: process.env.COGNITO_USER_POOL_CLIENT,
                AuthFlow: "USER_PASSWORD_AUTH",
                AuthParameters: {
                    USERNAME: username,
                    PASSWORD: password
                }
            }).promise();
            if (!AuthenticationResult)
                throw new Error(`Invalid authentication: challenge "${ChallengeName}"`);
            return {
                access: {
                    token: AuthenticationResult.IdToken,
                    expires: expires(60 * 60)
                },
                refresh: {
                    token: AuthenticationResult.RefreshToken,
                    expires: expires(60 * 60 * 24 * 30)
                }
            };
        }
        catch (err) {
            throw translate(err);
        }
    }
    async authenticateWithToken(token) {
        try {
            const { AuthenticationResult, ChallengeName } = await this.cognito.initiateAuth({
                ClientId: process.env.COGNITO_USER_POOL_CLIENT,
                AuthFlow: "REFRESH_TOKEN",
                AuthParameters: {
                    REFRESH_TOKEN: token
                }
            }).promise();
            if (!AuthenticationResult)
                throw new Error(`Invalid authentication: challenge "${ChallengeName}"`);
            return {
                access: {
                    token: AuthenticationResult.IdToken,
                    expires: expires(60 * 60)
                }
            };
        }
        catch (err) {
            throw translate(err);
        }
    }
}
exports.AuthenticationClient = AuthenticationClient;
