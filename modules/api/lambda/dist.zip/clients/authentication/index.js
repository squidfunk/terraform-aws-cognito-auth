"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const email_validator_1 = require("email-validator");
const uuid_1 = require("uuid");
const verification_1 = require("../../verification");
const _1 = require("../_");
function expires(seconds) {
    return new Date(Date.now() + seconds * 1000);
}
exports.expires = expires;
function translate(err) {
    switch (err.code) {
        case "InvalidParameterException":
            err.code = "TypeError";
            err.message = "Invalid request";
            return err;
        case "UserNotFoundException":
            err.code = "NotAuthorizedException";
            err.message = "Incorrect username or password";
            return err;
        default:
            return err;
    }
}
exports.translate = translate;
class AuthenticationClient extends _1.Client {
    constructor(verification = new verification_1.Verification()) {
        super();
        this.verification = verification;
    }
    async register(email, password, zohoId) {
        const username = uuid_1.v4();
        if (!email_validator_1.validate(email))
            throw new Error("Invalid email address");
        await this.cognito.signUp({
            ClientId: process.env.COGNITO_USER_POOL_CLIENT_ID,
            Username: username,
            Password: password,
            UserAttributes: [
                {
                    Name: "email",
                    Value: email
                },
                {
                    Name: "zohoId",
                    Value: zohoId
                }
            ]
        }).promise();
        return this.verification.issue("register", username);
    }
    async authenticateWithCredentials(username, password) {
        try {
            const { AuthenticationResult, ChallengeName } = await this.cognito.initiateAuth({
                ClientId: process.env.COGNITO_USER_POOL_CLIENT_ID,
                AuthFlow: "USER_PASSWORD_AUTH",
                AuthParameters: {
                    USERNAME: username,
                    PASSWORD: password
                }
            }).promise();
            if (!AuthenticationResult)
                throw new Error(`Invalid authentication: challenge "${ChallengeName}"`);
            return {
                id: {
                    token: AuthenticationResult.IdToken,
                    expires: expires(60 * 60)
                },
                access: {
                    token: AuthenticationResult.AccessToken,
                    expires: expires(60 * 60)
                },
                refresh: {
                    token: AuthenticationResult.RefreshToken,
                    expires: expires(60 * 60 * 24 * 30)
                }
            };
        }
        catch (err) {
            throw translate(err);
        }
    }
    async authenticateWithToken(token) {
        try {
            const { AuthenticationResult, ChallengeName } = await this.cognito.initiateAuth({
                ClientId: process.env.COGNITO_USER_POOL_CLIENT_ID,
                AuthFlow: "REFRESH_TOKEN",
                AuthParameters: {
                    REFRESH_TOKEN: token
                }
            }).promise();
            if (!AuthenticationResult)
                throw new Error(`Invalid authentication: challenge "${ChallengeName}"`);
            return {
                id: {
                    token: AuthenticationResult.IdToken,
                    expires: expires(60 * 60)
                },
                access: {
                    token: AuthenticationResult.AccessToken,
                    expires: expires(60 * 60)
                }
            };
        }
        catch (err) {
            throw translate(err);
        }
    }
    async forgotPassword(username) {
        const { Username: id } = await this.cognito.adminGetUser({
            UserPoolId: process.env.COGNITO_USER_POOL_ID,
            Username: username
        }).promise();
        return this.verification.issue("reset", id);
    }
}
exports.AuthenticationClient = AuthenticationClient;
