"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const clients_1 = require("clients");
class SessionClient extends clients_1.Client {
    constructor(token) {
        super();
        this.token = token;
    }
    async changePassword(previous, proposed) {
        await this.cognito.changePassword({
            AccessToken: this.token,
            PreviousPassword: previous,
            ProposedPassword: proposed
        }).promise();
    }
    async signOut() {
        await this.cognito.globalSignOut({
            AccessToken: this.token
        }).promise();
    }
}
exports.SessionClient = SessionClient;
