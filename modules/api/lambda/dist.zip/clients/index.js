"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Client {
    constructor(cognito) {
        this.cognito = cognito;
    }
}
exports.Client = Client;
