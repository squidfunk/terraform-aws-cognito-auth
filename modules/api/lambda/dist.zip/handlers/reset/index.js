"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const authentication_1 = require("clients/authentication");
const handlers_1 = require("handlers");
const schema = require("common/events/reset/index.json");
exports.post = handlers_1.handler(schema, async ({ body: { username } }) => {
    const auth = new authentication_1.AuthenticationClient();
    await auth.forgotPassword(username);
});
