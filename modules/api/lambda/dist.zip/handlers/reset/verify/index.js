"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __1 = require("../..");
const authentication_1 = require("../../../clients/authentication");
const management_1 = require("../../../clients/management");
const schema = require("./@schema/post.json");
exports.post = __1.handler(schema, async ({ code, password }) => {
    const auth = new authentication_1.AuthenticationClient();
    const mgmt = new management_1.ManagementClient();
    const { subject } = await auth.verify("reset", code);
    await mgmt.changePassword(subject, password);
});
