"use strict";
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
const authentication_1 = require("clients/authentication");
const handlers_1 = require("handlers");
const utilities_1 = require("utilities");
const schema = require("common/events/authenticate/index.json");
exports.post = handlers_1.handler(schema, async ({ headers, body: { username, password, remember, token } }) => {
    const auth = new authentication_1.AuthenticationClient();
    if (username && password) {
        const _a = await auth.authenticateWithCredentials(username, password), { refresh } = _a, body = __rest(_a, ["refresh"]);
        return Object.assign({ body: remember ? Object.assign({}, body, { refresh }) : body }, (remember && refresh
            ? {
                headers: {
                    "Set-Cookie": utilities_1.issueTokenCookie(refresh)
                }
            }
            : {}));
    }
    else {
        token = token || utilities_1.parseTokenCookie(headers.Cookie);
        try {
            const session = await auth.authenticateWithToken(token);
            return {
                body: session
            };
        }
        catch (err) {
            err.code = err.code || err.name;
            return {
                statusCode: err.statusCode || 400,
                body: {
                    type: err.code,
                    message: err.message.replace(/\.$/, "")
                },
                headers: {
                    "Set-Cookie": utilities_1.resetTokenCookie()
                }
            };
        }
    }
});
