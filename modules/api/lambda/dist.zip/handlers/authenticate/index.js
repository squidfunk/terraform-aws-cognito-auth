"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cookie = require("cookie");
const authentication_1 = require("clients/authentication");
const handlers_1 = require("handlers");
const schema = require("common/events/authenticate/index.json");
function parseCookie(value) {
    if (!(value && value.length))
        throw new TypeError("Invalid request");
    const { "__Secure-token": token } = cookie.parse(value);
    return token;
}
function generateSetCookie({ token, expires }, path) {
    return cookie.serialize("__Secure-token", token, {
        expires,
        domain: process.env.COGNITO_IDENTITY_DOMAIN,
        path,
        secure: true,
        httpOnly: true,
        sameSite: true
    });
}
exports.post = handlers_1.handler(schema, async ({ path, headers, body: { username, password, token } }) => {
    const auth = new authentication_1.AuthenticationClient();
    const session = await auth.authenticate(username || token ||
        parseCookie(headers.Cookie), password);
    return Object.assign({ body: session }, (session.refresh
        ? {
            headers: {
                "Set-Cookie": generateSetCookie(session.refresh, path)
            }
        }
        : {}));
});
