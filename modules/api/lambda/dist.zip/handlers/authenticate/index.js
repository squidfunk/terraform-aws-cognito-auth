"use strict";
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0)
            t[p[i]] = s[p[i]];
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
const cookie = require("cookie");
const authentication_1 = require("clients/authentication");
const handlers_1 = require("handlers");
const schema = require("common/events/authenticate/index.json");
const TOKEN_COOKIE_NAME = "__Secure-token";
function parseToken(value) {
    if (!(value && value.length))
        throw new TypeError("Invalid request");
    const { [TOKEN_COOKIE_NAME]: token } = cookie.parse(value);
    return token;
}
function issueToken({ token, expires }, path) {
    return cookie.serialize(TOKEN_COOKIE_NAME, token, {
        expires,
        domain: process.env.COGNITO_IDENTITY_POOL_PROVIDER,
        path,
        secure: true,
        httpOnly: true,
        sameSite: true
    });
}
function resetToken(path) {
    return cookie.serialize(TOKEN_COOKIE_NAME, "", {
        expires: new Date(0),
        domain: process.env.COGNITO_IDENTITY_POOL_PROVIDER,
        path,
        secure: true,
        httpOnly: true,
        sameSite: true
    });
}
exports.post = handlers_1.handler(schema, async ({ path, headers, body: { username, password, remember, token } }) => {
    const auth = new authentication_1.AuthenticationClient();
    try {
        const session = await auth.authenticate(username || token || parseToken(headers.Cookie), password);
        const { refresh } = session, body = __rest(session, ["refresh"]);
        return Object.assign({ body: remember ? Object.assign({}, body, { refresh }) : body }, (remember && refresh
            ? {
                headers: {
                    "Set-Cookie": issueToken(refresh, path)
                }
            }
            : {}));
    }
    catch (err) {
        if (token) {
            err.code = err.code || err.name;
            return {
                statusCode: 403,
                body: JSON.stringify({
                    type: err.code,
                    message: err.message.replace(/\.$/, "")
                }),
                headers: {
                    "Set-Cookie": resetToken(path)
                }
            };
        }
        else {
            err.statusCode = 403;
            throw err;
        }
    }
});
