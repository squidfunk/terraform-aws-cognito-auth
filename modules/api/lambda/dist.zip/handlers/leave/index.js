"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const clients_1 = require("../../clients");
const utilities_1 = require("../../utilities");
const _1 = require("../_");
const schema = require("../../common/events/leave/index.json");
exports.post = _1.handler(schema, async ({ headers }) => {
    const token = utilities_1.parseTokenFromHeader(headers.Authorization);
    try {
        const session = new clients_1.SessionClient(token);
        await session.signOut();
        return {
            headers: {
                "Set-Cookie": utilities_1.resetTokenCookie()
            }
        };
    }
    catch (err) {
        err.code = err.code || err.name;
        return {
            statusCode: err.statusCode || 400,
            body: {
                type: err.code,
                message: err.message.replace(/\.$/, "")
            },
            headers: {
                "Set-Cookie": utilities_1.resetTokenCookie()
            }
        };
    }
});
