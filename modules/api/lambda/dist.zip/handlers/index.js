"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsonschema_1 = require("jsonschema");
function translate(err) {
    switch (err.code) {
        case "SyntaxError":
            err.code = "TypeError";
            err.message = "Invalid request";
            return err;
        case "UserLambdaValidationException":
            err.code = "AliasExistsException";
            err.message = err.message.replace("PreSignUp failed with error ", "");
            return err;
        default:
            return err;
    }
}
exports.translate = translate;
function handler(schema, cb) {
    return async (event) => {
        try {
            const data = event.httpMethod === "POST"
                ? JSON.parse(event.body || "{}")
                : {};
            const result = jsonschema_1.validate(data, schema);
            if (!result.valid)
                throw new TypeError("Invalid request");
            const { statusCode, headers, body } = Object.assign({ statusCode: 200, headers: {}, body: undefined }, (await cb({
                path: event.path,
                pathParameters: event.pathParameters,
                headers: event.headers,
                body: data
            })));
            return {
                statusCode,
                headers,
                body: body ? JSON.stringify(body) : "{}"
            };
        }
        catch (err) {
            err.code = err.code || err.name;
            err = translate(err);
            return {
                statusCode: err.statusCode || 400,
                body: JSON.stringify({
                    type: err.code,
                    message: err.message.replace(/\.$/, "")
                })
            };
        }
    };
}
exports.handler = handler;
