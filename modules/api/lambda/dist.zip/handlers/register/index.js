"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const __1 = require("..");
const authentication_1 = require("../../clients/authentication");
exports.post = __1.handler("register", async ({ email, password }) => {
    const auth = new authentication_1.AuthenticationClient();
    try {
        await auth.register(email, password);
    }
    catch (err) {
        if (err.code === "UserLambdaValidationException") {
            err.code = "AliasExistsException";
            err.message = err.message.replace("PreSignUp failed with error ", "");
        }
        throw err;
    }
});
