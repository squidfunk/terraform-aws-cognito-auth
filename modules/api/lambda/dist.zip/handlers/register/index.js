"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const clients_1 = require("../../clients");
const utilities_1 = require("../../utilities");
const _1 = require("../_");
const schema = require("../../common/events/register/index.json");
exports.post = _1.handler(schema, async ({ body: { email, password, phoneNumber, firstName, lastName } }) => {
    utilities_1.throwOnPasswordPolicyViolation(password);
    const auth = new clients_1.AuthenticationClient();
    try {
        const zohoId = await clients_1.ZohoClient.newLead({ email, phoneNumber, firstName, lastName });
        await auth.register(email, password, zohoId);
        return { body: { newLeadId: zohoId } };
    }
    catch (e) {
        console.debug('[zoho]: creation failed', email, password, phoneNumber, firstName, lastName);
        return {};
    }
});
