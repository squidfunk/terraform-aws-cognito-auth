"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const authentication_1 = require("clients/authentication");
const handlers_1 = require("handlers");
const schema = require("common/events/register/index.json");
exports.post = handlers_1.handler(schema, async ({ body: { email, password } }) => {
    const auth = new authentication_1.AuthenticationClient();
    await auth.register(email, password);
});
