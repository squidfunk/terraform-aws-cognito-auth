"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const management_1 = require("clients/management");
const handlers_1 = require("handlers");
const verification_1 = require("verification");
const schema = require("common/events/register/verify/index.json");
exports.post = handlers_1.handler(schema, async ({ pathParameters: { code } }) => {
    const verification = new verification_1.Verification();
    const mgmt = new management_1.ManagementClient();
    const { subject } = await verification.claim("register", code);
    await mgmt.verifyUser(subject);
});
