"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const session_1 = require("clients/session");
const handlers_1 = require("handlers");
const schema = require("common/events/user/leave/index.json");
exports.post = handlers_1.handler(schema, async ({ headers }) => {
    const token = (headers.Authorization || "").replace(/^Bearer\s+/, "");
    try {
        const session = new session_1.SessionClient(token);
        await session.signOut();
        return {
            statusCode: 204
        };
    }
    catch (err) {
        err.statusCode = 403;
        throw err;
    }
});
