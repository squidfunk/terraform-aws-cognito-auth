"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const rules = require("password-rules");
function throwOnPasswordPolicyBreach(password) {
    const result = rules(password, {
        minimumLength: 8,
        requireCapital: true,
        requireLower: true,
        requireNumber: true,
        requireSpecial: true
    });
    if (result)
        throw new Error(result.sentence);
}
exports.throwOnPasswordPolicyBreach = throwOnPasswordPolicyBreach;
