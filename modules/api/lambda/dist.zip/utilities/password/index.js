"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const rules = require("password-rules");
function throwOnPasswordPolicyViolation(password) {
    const result = rules(password, {
        minimumLength: 8,
        maximumLength: 256,
        requireCapital: true,
        requireLower: true,
        requireNumber: true,
        requireSpecial: true
    });
    if (result)
        throw new Error(result.sentence);
}
exports.throwOnPasswordPolicyViolation = throwOnPasswordPolicyViolation;
