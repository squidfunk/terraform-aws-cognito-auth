"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const rules = require("password-rules");
function validate(password) {
    const result = rules(password, {
        minimumLength: 8,
        requireCapital: true,
        requireLower: true,
        requireNumber: true,
        requireSpecial: true
    });
    if (result)
        throw new Error(result.sentence);
}
exports.validate = validate;
