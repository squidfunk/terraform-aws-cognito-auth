"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cookie = require("cookie");
exports.TOKEN_COOKIE_NAME = "__Secure-token";
exports.TOKEN_COOKIE_PATH = `/${process.env.API_BASE_PATH}/authenticate`;
function parseTokenCookie(value) {
    if (!(value && value.length))
        throw new TypeError("Invalid request");
    const { [exports.TOKEN_COOKIE_NAME]: token } = cookie.parse(value);
    return token;
}
exports.parseTokenCookie = parseTokenCookie;
function issueTokenCookie({ token, expires }) {
    return cookie.serialize(exports.TOKEN_COOKIE_NAME, token, {
        expires,
        domain: process.env.COGNITO_IDENTITY_POOL_PROVIDER,
        path: exports.TOKEN_COOKIE_PATH,
        secure: true,
        httpOnly: true,
        sameSite: true
    });
}
exports.issueTokenCookie = issueTokenCookie;
function resetTokenCookie() {
    return cookie.serialize(exports.TOKEN_COOKIE_NAME, "", {
        expires: new Date(0),
        domain: process.env.COGNITO_IDENTITY_POOL_PROVIDER,
        path: exports.TOKEN_COOKIE_PATH,
        secure: true,
        httpOnly: true,
        sameSite: true
    });
}
exports.resetTokenCookie = resetTokenCookie;
