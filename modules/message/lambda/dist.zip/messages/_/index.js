"use strict";
/*
 * Copyright (c) 2018-2019 Martin Donath <martin.donath@squidfunk.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Message = void 0;
// tslint:disable no-duplicate-string
const fs_1 = require("fs");
const mime_1 = require("mime");
const mimemessage_1 = require("mimemessage");
const mustache_1 = require("mustache");
const path = require("path");
const quoted_printable_1 = require("quoted-printable");
const util_1 = require("util");
/* ----------------------------------------------------------------------------
 * Class
 * ------------------------------------------------------------------------- */
/**
 * Abstract message base class
 *
 * @template TData - Message data type
 */
class Message {
    /**
     * Initialize message
     *
     * @param template - Template
     * @param data - Message data
     */
    constructor(template, data) {
        this.template = template;
        this.data = data;
        this.base = path.join(__dirname, "..", template);
    }
    /**
     * Return message body
     *
     * @return Promise resolving with message body
     */
    async body() {
        const [text, html] = await Promise.all([
            util_1.promisify(fs_1.readFile)(path.resolve(this.base, "index.txt"), "utf8"),
            util_1.promisify(fs_1.readFile)(path.resolve(this.base, "index.html"), "utf8")
        ]);
        return {
            text: mustache_1.render(text, this.data),
            html: mustache_1.render(html, this.data).replace(/attachments\//, "cid:")
        };
    }
    /**
     * Return message attachments
     *
     * @return Promise resolving with message attachments
     */
    async attachments() {
        const base = path.resolve(this.base, "attachments");
        const filelist = await util_1.promisify(fs_1.readdir)(base);
        return Promise.all(filelist
            .filter(file => mime_1.getType(file) === "image/png")
            .map(async (file) => {
            const data = await util_1.promisify(fs_1.readFile)(path.resolve(base, file));
            return {
                id: file,
                type: mime_1.getType(file),
                data: data.toString("base64").match(/.{1,76}/g).join("\r\n")
            };
        }));
    }
    /**
     * Compose MIME message
     *
     * @return Mime entity
     */
    async compose() {
        const [body, attachments] = await Promise.all([
            this.body(),
            this.attachments()
        ]);
        /* Compose message entity */
        const message = mimemessage_1.factory({
            contentType: "multipart/mixed",
            body: [
                /* Entity containing plain text and HTML entities */
                mimemessage_1.factory({
                    contentType: "multipart/alternative",
                    body: [
                        /* Plain text entity */
                        mimemessage_1.factory({
                            contentType: "text/plain; charset=UTF-8",
                            contentTransferEncoding: "quoted-printable",
                            body: quoted_printable_1.encode(body.text)
                        }),
                        /* HTML entity */
                        mimemessage_1.factory({
                            contentType: "text/html; charset=UTF-8",
                            contentTransferEncoding: "quoted-printable",
                            body: quoted_printable_1.encode(body.html)
                        })
                    ]
                }),
                /* Attachment entities */
                ...attachments.map(attachment => {
                    const entity = mimemessage_1.factory({
                        contentType: attachment.type,
                        contentTransferEncoding: "base64",
                        body: attachment.data
                    });
                    entity.header("Content-Disposition", "inline");
                    entity.header("Content-ID", `<${attachment.id}>`);
                    return entity;
                })
            ]
        });
        /* Set subject and return MIME entity */
        message.header("Subject", this.subject);
        return message;
    }
}
exports.Message = Message;
