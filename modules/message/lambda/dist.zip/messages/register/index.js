"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mustache_1 = require("mustache");
const messages_1 = require("messages");
class RegisterMessage extends messages_1.Message {
    constructor(data) {
        super("register", data);
        this.data = data;
    }
    get subject() {
        return mustache_1.render("Activate your {{name}} account", this.data);
    }
}
exports.RegisterMessage = RegisterMessage;
