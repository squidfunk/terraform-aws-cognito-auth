"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mustache_1 = require("mustache");
const messages_1 = require("messages");
class ResetMessage extends messages_1.Message {
    constructor(data) {
        super("reset", data);
        this.data = data;
    }
    get subject() {
        return mustache_1.render("Unlock your {{name}} account", this.data);
    }
}
exports.ResetMessage = ResetMessage;
