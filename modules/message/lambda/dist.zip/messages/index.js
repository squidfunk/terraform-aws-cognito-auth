"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = require("fs");
const mime_1 = require("mime");
const mimemessage_1 = require("mimemessage");
const mustache_1 = require("mustache");
const path = require("path");
const quoted_printable_1 = require("quoted-printable");
const util_1 = require("util");
class Message {
    constructor(template, data) {
        this.template = template;
        this.data = data;
        this.base = path.join(__dirname, template);
    }
    async body() {
        const [text, html] = await Promise.all([
            util_1.promisify(fs_1.readFile)(path.resolve(this.base, "index.txt"), "utf8"),
            util_1.promisify(fs_1.readFile)(path.resolve(this.base, "index.html"), "utf8")
        ]);
        return {
            text: mustache_1.render(text, this.data),
            html: mustache_1.render(html, this.data).replace(/attachments\//, "cid:")
        };
    }
    async attachments() {
        const base = path.resolve(this.base, "attachments");
        const filelist = await util_1.promisify(fs_1.readdir)(base);
        return Promise.all(filelist
            .filter(file => mime_1.getType(file) === "image/png")
            .map(async (file) => {
            const data = await util_1.promisify(fs_1.readFile)(path.resolve(base, file));
            return {
                id: file,
                type: mime_1.getType(file),
                data: data.toString("base64").match(/.{1,76}/g).join("\r\n")
            };
        }));
    }
    async compose() {
        const [body, attachments] = await Promise.all([
            this.body(),
            this.attachments()
        ]);
        const message = mimemessage_1.factory({
            contentType: "multipart/mixed",
            body: [
                mimemessage_1.factory({
                    contentType: "multipart/alternative",
                    body: [
                        mimemessage_1.factory({
                            contentType: "text/plain; charset=UTF-8",
                            contentTransferEncoding: "quoted-printable",
                            body: quoted_printable_1.encode(body.text)
                        }),
                        mimemessage_1.factory({
                            contentType: "text/html; charset=UTF-8",
                            contentTransferEncoding: "quoted-printable",
                            body: quoted_printable_1.encode(body.html)
                        })
                    ]
                }),
                ...attachments.map(attachment => {
                    const entity = mimemessage_1.factory({
                        contentType: attachment.type,
                        contentTransferEncoding: "base64",
                        body: attachment.data
                    });
                    entity.header("Content-Disposition", "inline");
                    entity.header("Content-ID", `<${attachment.id}>`);
                    return entity;
                })
            ]
        });
        message.header("Subject", this.subject);
        return message;
    }
}
exports.Message = Message;
