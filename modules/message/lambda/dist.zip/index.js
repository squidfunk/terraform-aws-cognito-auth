"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const emailjs_1 = require("emailjs");
console.log(emailjs_1.message);
const m = emailjs_1.message.create({
    text: "i hope this works",
    from: "you <scifish@gmail.com>",
    to: "someone <scifish@gmail.com>",
    subject: "testing emailjs",
    attachment: [
        { data: "<html>i <i>hope</i> this works! here is an image: <img src='cid:my-image' width='100' height ='50'> </html>" },
        { path: "../dist/templates/images/register.png", type: "image/png", headers: { "Content-ID": "<my-image>" } }
    ]
});
const s = m.stream();
s.on("data", data => {
    console.log(data);
});
