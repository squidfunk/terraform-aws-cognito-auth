"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const message_1 = require("./message");
async function handler(event) {
    await event.Records.reduce(async (promise, record) => promise.then(async () => {
        const code = JSON.parse(record.Sns.Message);
        await new message_1.Message(code).send();
    }), Promise.resolve());
}
exports.handler = handler;
process.on("unhandledRejection", () => {
});
