"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const messages_1 = require("./messages");
function template(code) {
    switch (code.context) {
        case "register":
            return new messages_1.RegisterMessage({
                name: process.env.COGNITO_IDENTITY_NAME,
                domain: process.env.COGNITO_IDENTITY_DOMAIN,
                code: code.id
            });
        case "reset":
            return new messages_1.ResetMessage({
                name: process.env.COGNITO_IDENTITY_NAME,
                domain: process.env.COGNITO_IDENTITY_DOMAIN,
                code: code.id
            });
        default:
            throw new Error(`Invalid context: "${code.context}"`);
    }
}
async function handler(event) {
    try {
        await event.Records.reduce(async (promise, record) => promise.then(async () => {
            const code = JSON.parse(record.Sns.Message);
            const [{ UserAttributes }, message] = await Promise.all([
                new aws_sdk_1.CognitoIdentityServiceProvider({ apiVersion: "2016-04-18" })
                    .adminGetUser({
                    UserPoolId: process.env.COGNITO_USER_POOL,
                    Username: code.subject
                }).promise(),
                template(code).compose()
            ]);
            const { Value: email } = UserAttributes.find(attr => {
                return attr.Name === "email";
            });
            await new aws_sdk_1.SES({ apiVersion: "2010-12-01" })
                .sendRawEmail({
                Source: process.env.SES_SENDER_ADDRESS,
                Destinations: [email],
                RawMessage: {
                    Data: message.toString()
                }
            }).promise();
        }), Promise.resolve());
    }
    catch (err) {
        throw err;
    }
}
exports.handler = handler;
