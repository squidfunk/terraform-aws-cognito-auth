"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const register_1 = require("messages/register");
const reset_1 = require("messages/reset");
const domain = `${process.env.COGNITO_IDENTITY_SUBDOMAIN}.${process.env.COGNITO_IDENTITY_DOMAIN}`;
function template(code) {
    switch (code.context) {
        case "register":
            return new register_1.RegisterMessage({
                name: process.env.COGNITO_IDENTITY_NAME,
                domain,
                code: code.id
            });
        case "reset":
            return new reset_1.ResetMessage({
                name: process.env.COGNITO_IDENTITY_NAME,
                domain,
                code: code.id
            });
        default:
            throw new Error(`Invalid verification context: "${code.context}"`);
    }
}
async function handler(event) {
    return event.Records.reduce(async (promise, record) => promise.then(async () => {
        const code = JSON.parse(record.Sns.Message);
        const [{ UserAttributes }, message] = await Promise.all([
            new aws_sdk_1.CognitoIdentityServiceProvider({ apiVersion: "2016-04-18" })
                .adminGetUser({
                UserPoolId: process.env.COGNITO_USER_POOL,
                Username: code.subject
            }).promise(),
            template(code).compose()
        ]);
        const { Value: email } = UserAttributes.find(attr => {
            return attr.Name === "email";
        });
        if (email && !email.match(/@example\.com$/))
            await new aws_sdk_1.SES({ apiVersion: "2010-12-01" })
                .sendRawEmail({
                Source: process.env.SES_SENDER_ADDRESS,
                Destinations: [email],
                RawMessage: {
                    Data: message.toString()
                }
            }).promise();
    }), Promise.resolve());
}
exports.handler = handler;
process.on("unhandledRejection", () => {
});
