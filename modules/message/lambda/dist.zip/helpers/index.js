"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = require("fs");
const util_1 = require("util");
function load(filename) {
    return util_1.promisify(fs_1.readFile)(filename, {
        encoding: "utf8"
    });
}
exports.load = load;
