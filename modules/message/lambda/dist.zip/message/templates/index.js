"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mustache_1 = require("mustache");
const path_1 = require("path");
const helpers_1 = require("../../helpers");
class MessageTemplate {
    constructor(name, data) {
        this.name = name;
        this.data = data;
    }
    async render() {
        const [html, text] = await Promise.all([
            helpers_1.load(path_1.resolve(__dirname, `${this.name}/index.html`)),
            helpers_1.load(path_1.resolve(__dirname, `${this.name}/index.txt`))
        ]);
        return {
            html: mustache_1.render(html, this.data),
            text: mustache_1.render(text, this.data)
        };
    }
}
exports.MessageTemplate = MessageTemplate;
var register_1 = require("./register");
exports.RegisterTemplate = register_1.RegisterTemplate;
var reset_1 = require("./reset");
exports.ResetTemplate = reset_1.ResetTemplate;
