"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mustache_1 = require("mustache");
const __1 = require("..");
class RegisterTemplate extends __1.MessageTemplate {
    constructor(data) {
        super("register", data);
        this.data = data;
    }
    get subject() {
        return mustache_1.render("Activate your {{pool}} account", this.data);
    }
}
exports.RegisterTemplate = RegisterTemplate;
