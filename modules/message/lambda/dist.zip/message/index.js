"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const emailjs_1 = require("emailjs");
const templates_1 = require("./templates");
class Message {
    constructor(code, cognito = new aws_sdk_1.CognitoIdentityServiceProvider({
        apiVersion: "2016-04-18"
    })) {
        this.code = code;
        this.cognito = cognito;
    }
    async send() {
        const { UserAttributes } = await this.cognito.adminGetUser({
            UserPoolId: process.env.COGNITO_USER_POOL,
            Username: this.code.subject
        }).promise();
        const { Value: email } = UserAttributes.find(attr => {
            return attr.Name === "email";
        });
        console.log(email);
        const template = new templates_1.RegisterTemplate({
            pool: process.env.COGNITO_IDENTITY_NAME,
            domain: process.env.COGNITO_IDENTITY_DOMAIN,
            code: this.code.id
        });
        const body = await template.render();
        const stream = emailjs_1.message.create({
            from: "you <scifish@gmail.com>",
            to: "someone <scifish@gmail.com>",
            subject: "template.subject()",
            text: body.text,
            attachment: [
                {
                    data: body.html,
                    alternative: true
                },
                {
                    path: "templates/images/register.png",
                    type: "image/png",
                    headers: {
                        "Content-ID": "<my-image>"
                    }
                }
            ]
        }).stream();
        const msg = await new Promise((resolve, reject) => {
            stream.on("end", resolve);
            stream.on("error", reject);
        });
        console.log(msg);
    }
}
exports.Message = Message;
