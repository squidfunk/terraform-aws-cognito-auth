"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
async function handler(event) {
    const response = event.Records[0].cf.response;
    const headers = {
        "Content-Security-Policy": [
            "default-src 'self'",
            "style-src 'self' 'unsafe-inline'"
        ].join("; "),
        "Strict-Transport-Security": [
            "max-age=31536000",
            "includeSubdomains",
            "preload"
        ].join("; "),
        "Referrer-Policy": "no-referrer",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "X-XSS-Protection": [
            "1",
            "mode=block"
        ].join("; ")
    };
    Object.keys(headers).forEach(key => {
        response.headers[key] = [
            {
                key,
                value: headers[key]
            }
        ];
    });
    return response;
}
exports.handler = handler;
