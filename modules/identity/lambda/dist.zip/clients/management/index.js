"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _1 = require("../_");
class ManagementClient extends _1.Client {
    async addUserToGroup(username, userPoolId, groupName) {
        await this.cognito.adminAddUserToGroup({
            GroupName: groupName,
            UserPoolId: userPoolId,
            Username: username
        }).promise();
    }
}
exports.ManagementClient = ManagementClient;
