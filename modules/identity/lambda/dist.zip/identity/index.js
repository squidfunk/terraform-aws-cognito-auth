"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
async function handler(event) {
    console.log('got here?');
    const { Users } = await new aws_sdk_1.CognitoIdentityServiceProvider({
        apiVersion: "2016-04-18"
    }).listUsers({
        UserPoolId: event.userPoolId,
        Filter: `email="${event.request.userAttributes.email}"`
    }).promise();
    console.log('got here1?');
    if (Users.length)
        throw new Error("Email address already registered");
    console.log('got here2?');
    console.log('got here3?');
    return event;
}
exports.handler = handler;
