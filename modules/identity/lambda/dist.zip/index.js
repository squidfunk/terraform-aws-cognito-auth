"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const identity_1 = require("./identity");
const postConfirmation_1 = require("./postConfirmation");
async function handler(event) {
    console.log('event triggersrc: ', event.triggerSource);
    switch (event.triggerSource) {
        default:
        case 'PreSignUp_SignUp':
            return identity_1.handler(event);
        case 'PostConfirmation_ConfirmForgotPassword':
        case 'PostConfirmation_ConfirmSignUp':
            return postConfirmation_1.handler(event);
    }
}
exports.handler = handler;
