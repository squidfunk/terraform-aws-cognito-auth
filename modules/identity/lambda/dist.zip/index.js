"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
process.on("unhandledRejection", () => { });
async function trigger(event) {
    try {
        await new aws_sdk_1.CognitoIdentityServiceProvider({
            apiVersion: "2016-04-18"
        }).adminGetUser({
            UserPoolId: event.userPoolId,
            Username: event.request.userAttributes.email
        }).promise();
        throw new Error("Email address already registered");
    }
    catch (err) {
        if (err.code && err.code === "UserNotFoundException")
            return event;
        throw err;
    }
}
exports.trigger = trigger;
