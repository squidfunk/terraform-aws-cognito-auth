"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
async function handler(event) {
    const { Users } = await new aws_sdk_1.CognitoIdentityServiceProvider({
        apiVersion: "2016-04-18"
    }).listUsers({
        UserPoolId: event.userPoolId,
        Filter: `email="${event.request.userAttributes.email}"`
    }).promise();
    if (Users.length)
        throw new Error("Email address already registered");
    return event;
}
exports.handler = handler;
