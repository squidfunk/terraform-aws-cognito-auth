"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const management_1 = require("clients/management");
async function handler(event) {
    try {
        const mgmt = new management_1.ManagementClient();
        console.log('Got inside adduserToGroup handler', event.userName, event.userPoolId, process.env.COGNITO_USER_GROUP_NAME);
        await mgmt.addUserToGroup(event.userName, event.userPoolId, process.env.COGNITO_USER_GROUP_NAME);
        return event;
    }
    catch (err) {
        console.log(err);
        throw new Error("Could not add user to group");
    }
}
exports.handler = handler;
